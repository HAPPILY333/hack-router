apt-get update
apt-get upgrade
apt-get install openssh
apt-get install ssh
